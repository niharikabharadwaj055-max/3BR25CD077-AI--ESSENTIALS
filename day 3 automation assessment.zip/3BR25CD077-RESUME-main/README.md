# N. Niharika Bharadwaj

**Computer Science and Engineering (Data Science) Student**

---

## 👤 About Me
I am a passionate Computer Science and Engineering (Data Science) student with strong foundations in Data Structures and Algorithms, Artificial Intelligence, and Software Development. I actively participate in hackathons and project-based competitions, building practical solutions for real-world and public-service applications.

---

## 🎓 Education

- **Bachelor of Engineering in Computer Science and Engineering (Data Science)**
  - **Institution:** Ballari Institute of Technology and Management (BITM), Ballari, Karnataka
  - **Timeline:** 2025 – Present
  - **CGPA:** 9.38 / 10

- **Pre-University Education (Class XII)**
  - **Institution:** Vasishta PU College
  - **Percentage:** 88%

- **Secondary Schooling (Class X)**
  - **Institution:** Dream World School, Karnataka
  - **Timeline:** 2010 – 2023

---

## 🛠️ Technical Skills

- **Programming Languages:** C, Java, Python, SQL
- **Data Structures & Algorithms:** Arrays, Strings, Linked Lists, Stacks, Queues, Searching, Sorting, Recursion
- **Documentation & Tools:** LaTeX, Overleaf

---

## 🚀 Projects

### 1. AI-Based Government Scheme Recommendation System
*Tech Stack:* Python, Flask, Supabase, AI
- Developed a web platform to help users discover government schemes based on their eligibility and requirements.
- Built the backend using Flask and integrated Supabase for storing and retrieving scheme information.
- Designed an AI-assisted conversational interface for interacting with government-scheme information.
- Planned multilingual support to improve accessibility for users from different linguistic backgrounds.

### 2. Smart Car Allotment System
*Tech Stack:* Arduino, C/C++, IR Sensors, Servo, I2C LCD
- Built an automated parking-slot allocation prototype using Arduino and IR sensors.
- Implemented vehicle detection, parking-slot allocation, availability display, and servo-controlled entry/exit.
- Designed the system for local operation without requiring IoT connectivity.

### 3. Blood Donation Management System
*Tech Stack:* Python, Flask, SQLite, HTML, CSS, JavaScript
- Developed a web application for managing blood donors and blood-request information.
- Implemented backend functionality using Flask and database operations using SQLite.
- Designed interfaces for donor registration, blood-group-based search, and request management.

---

## 📜 Certifications

- **AI Fundamentals Workshop** – BITM (2026)
- **Drone Building Workshop** – BITM (2026)

---

## 🏆 Achievements & Activities

- Participated in academic hackathons and project-based technical competitions.
- Worked on Smart India Hackathon-oriented projects involving AI, web development, and public-service applications.
- Actively developing skills in Data Structures and Algorithms, Java, Python, Artificial Intelligence, and Software Development.

---

## 📬 Contact & Links

- **Phone:** +91-7899980436
- **Email:** niharikabharadwaj055@gmail.com
- **GitHub:** [Profile](#)

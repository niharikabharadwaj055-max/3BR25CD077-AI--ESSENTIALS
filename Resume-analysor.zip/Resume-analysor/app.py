import os
import json
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import pypdf
import docx
import google.generativeai as genai
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize Gemini API
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

app = FastAPI(
    title="AI Resume Analyzer",
    description="Full-stack AI Resume & ATS Analyzer Platform",
    version="1.0.0"
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Static directory
static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")


def extract_text_from_pdf(file_bytes: bytes) -> str:
    """Extract text content from uploaded PDF bytes."""
    import io
    text = ""
    reader = pypdf.PdfReader(io.BytesIO(file_bytes))
    for page in reader.pages:
        page_text = page.extract_text()
        if page_text:
            text += page_text + "\n"
    return text.strip()


def extract_text_from_docx(file_bytes: bytes) -> str:
    """Extract text content from uploaded DOCX bytes."""
    import io
    doc = docx.Document(io.BytesIO(file_bytes))
    full_text = []
    for para in doc.paragraphs:
        if para.text:
            full_text.append(para.text)
    return "\n".join(full_text).strip()


def extract_text(file: UploadFile, file_bytes: bytes) -> str:
    """Extract text based on file format."""
    filename = file.filename.lower() if file.filename else ""
    if filename.endswith(".pdf"):
        return extract_text_from_pdf(file_bytes)
    elif filename.endswith(".docx"):
        return extract_text_from_docx(file_bytes)
    elif filename.endswith(".txt"):
        return file_bytes.decode("utf-8", errors="ignore").strip()
    else:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file format. Please upload a PDF, DOCX, or TXT file."
        )


def analyze_with_ai(resume_text: str, job_description: Optional[str] = None) -> dict:
    """Send resume text (and optional job description) to Gemini LLM for structured analysis."""
    if not GEMINI_API_KEY:
        return {
            "candidate_name": "Sample Candidate",
            "email": "candidate@example.com",
            "phone": "+1 234 567 8900",
            "ats_score": 75,
            "overall_summary": "Extracted resume content successfully. Add your GEMINI_API_KEY in the environment / .env file to enable dynamic AI scoring and in-depth keyword analysis.",
            "skills": ["Python", "Problem Solving", "Git", "REST APIs"],
            "matched_skills": ["Python", "Git", "REST APIs"],
            "missing_skills": ["Docker", "Kubernetes", "AWS Cloud Architecture"],
            "experience_level": "Mid Level",
            "strengths": [
                "Clean document structure with clear section dividers",
                "Strong foundational programming skills presented"
            ],
            "weaknesses": [
                "Lacks quantifiable metrics (% impact, revenue growth, users served)",
                "Missing some modern cloud tooling keywords from target roles"
            ],
            "suggestions_for_improvement": [
                "Add 2-3 bullet points measuring business impact with numbers",
                "Integrate cloud deployment experience (AWS/GCP/Docker) in technical projects",
                "Tailor summary directly to target job profile"
            ],
            "recommended_job_roles": [
                "Backend Engineer",
                "Full-Stack Developer",
                "Python Developer"
            ]
        }

    model = genai.GenerativeModel("gemini-1.5-flash")

    prompt = f"""
You are an elite Applicant Tracking System (ATS) auditor and Senior Technical Recruiter.
Evaluate the resume below against the target job description (if provided).

=== RESUME TEXT ===
{resume_text}

=== JOB DESCRIPTION ===
{job_description if job_description else 'General Software Engineering / Tech Profile'}

Respond with ONLY a valid JSON object strictly matching this schema:
{{
  "candidate_name": "string",
  "email": "string",
  "phone": "string",
  "ats_score": integer (between 0 and 100),
  "overall_summary": "Concise 2-3 sentence overview of candidate profile and fit",
  "skills": ["skill1", "skill2"],
  "matched_skills": ["matched skill 1", "matched skill 2"],
  "missing_skills": ["missing skill 1", "missing skill 2"],
  "experience_level": "Entry Level / Mid Level / Senior / Lead",
  "strengths": ["bullet point 1", "bullet point 2"],
  "weaknesses": ["bullet point 1", "bullet point 2"],
  "suggestions_for_improvement": ["bullet point 1", "bullet point 2"],
  "recommended_job_roles": ["Role 1", "Role 2", "Role 3"]
}}
"""

    try:
        response = model.generate_content(
            prompt,
            generation_config={"response_mime_type": "application/json"}
        )
        return json.loads(response.text)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error generating AI analysis: {str(e)}"
        )


@app.get("/")
def serve_home():
    """Serve the frontend single-page web app."""
    index_file = os.path.join(static_dir, "index.html")
    if os.path.exists(index_file):
        return FileResponse(index_file)
    return {"message": "AI Resume Analyzer API is running. Check /docs."}


@app.post("/analyze")
async def analyze_resume_file(
    file: UploadFile = File(...),
    job_description: Optional[str] = Form(None)
):
    """Analyze uploaded resume file against job description."""
    file_bytes = await file.read()
    if not file_bytes:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    extracted_text = extract_text(file, file_bytes)
    if not extracted_text.strip():
        raise HTTPException(status_code=400, detail="Could not extract readable text from the file.")

    analysis_result = analyze_with_ai(extracted_text, job_description)
    return {
        "status": "success",
        "filename": file.filename,
        "analysis": analysis_result
    }


class TextAnalysisRequest(BaseModel):
    resume_text: str
    job_description: Optional[str] = None


@app.post("/analyze-text")
async def analyze_resume_text(request: TextAnalysisRequest):
    """Analyze raw resume text."""
    if not request.resume_text.strip():
        raise HTTPException(status_code=400, detail="resume_text cannot be empty.")

    analysis_result = analyze_with_ai(request.resume_text, request.job_description)
    return {
        "status": "success",
        "analysis": analysis_result
    }


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("app:app", host="0.0.0.0", port=port, reload=True)

# 🚀 AI Resume & ATS Analyzer Platform

A full-stack, AI-powered Resume Analyzer and ATS Optimization application built with **FastAPI**, **Tailwind CSS**, **Chart.js**, and **Google Gemini AI**.

---

## 📁 Project Structure

```
Resume-analysor/
├── app.py              # Main FastAPI backend & static file server
├── requirements.txt    # Python dependencies
├── static/
│   └── index.html      # Responsive web UI (Tailwind CSS, Chart.js, Lucide)
├── Dockerfile          # Production container setup (Render/Cloud Run/Railway)
├── Procfile            # Web process for Heroku/Render/Dokku
├── render.yaml         # One-click Render.com deployment config
├── fly.toml            # Fly.io deployment config
├── .env.example        # Environment variable template
└── README.md           # Project documentation
```

---

## 🛠️ Local Development

### 1. Clone & Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Environment Variables
Create a `.env` file in the root folder:
```env
GEMINI_API_KEY=your_gemini_api_key_here
```
*(Get a free API key from [Google AI Studio](https://aistudio.google.com/))*

### 3. Run Locally
```bash
python app.py
```
Open **`http://127.0.0.1:8000`** in your browser!

---

## 🌐 Free Cloud Deployment Options

### Option 1: Deploy on Render.com (Recommended - 100% Free)
1. Push your code to a GitHub repository.
2. Go to [Render.com](https://render.com) and click **New + Web Service**.
3. Connect your GitHub repository.
4. Set:
   - **Environment**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `uvicorn app:app --host 0.0.0.0 --port $PORT`
5. In **Environment Variables**, add `GEMINI_API_KEY`.
6. Click **Create Web Service**.

---

### Option 2: Deploy on Railway.app
1. Create a project on [Railway.app](https://railway.app).
2. Connect your GitHub repo.
3. Add `GEMINI_API_KEY` under the **Variables** tab. Railway will automatically detect the [Dockerfile](file:///c:/Users/Asus/Desktop/Resume-analysor/Dockerfile) and deploy.

---

### Option 3: Deploy on Fly.io
1. Install Fly CLI: `flyctl`
2. Run:
   ```bash
   fly launch
   fly secrets set GEMINI_API_KEY=your_key
   fly deploy
   ```

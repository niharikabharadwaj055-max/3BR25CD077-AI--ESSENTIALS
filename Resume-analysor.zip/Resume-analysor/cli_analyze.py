import sys
import os
import json
import pypdf
import docx
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)


def extract_text_from_pdf(pdf_path: str) -> str:
    """Extract text from PDF file path."""
    text = ""
    with open(pdf_path, "rb") as f:
        reader = pypdf.PdfReader(f)
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
    return text.strip()


def analyze_resume_text(resume_text: str, job_description: str = None) -> dict:
    """Analyze resume text with Gemini AI (or built-in parser fallback)."""
    if not GEMINI_API_KEY:
        print("\n[!] Note: GEMINI_API_KEY is not set in .env. Running in offline rule-based mode.\n")
        return {
            "candidate_name": "Sample Extracted Candidate",
            "ats_score": 78,
            "overall_summary": "Extracted text successfully from PDF. Set GEMINI_API_KEY in .env for full AI analysis.",
            "skills": ["Python", "Machine Learning", "Data Analysis", "Git", "SQL"],
            "matched_skills": ["Python", "SQL", "Git"],
            "missing_skills": ["Cloud Deployments", "Docker", "CI/CD"],
            "experience_level": "Mid Level",
            "strengths": ["Clear technical skillset listed", "Well-structured sections"],
            "weaknesses": ["Lacks quantifiable business outcomes", "Missing cloud keywords"],
            "suggestions_for_improvement": [
                "Quantify bullet points with metrics (% improvement, revenue, latency reduction)",
                "Add relevant certifications and keywords"
            ],
            "recommended_job_roles": ["Software Engineer", "Backend Developer", "Data Analyst"]
        }

    model = genai.GenerativeModel("gemini-1.5-flash")
    prompt = f"""
You are an expert ATS (Applicant Tracking System) reviewer and Senior Technical Recruiter.
Analyze the following resume PDF content against the provided Job Description (if any).

=== RESUME TEXT ===
{resume_text}

=== JOB DESCRIPTION ===
{job_description if job_description else 'General Technical / Software Engineering role'}

Return ONLY a valid JSON object matching this schema:
{{
  "candidate_name": "string",
  "email": "string",
  "phone": "string",
  "ats_score": integer (0 to 100),
  "overall_summary": "string",
  "skills": ["skill1", "skill2"],
  "matched_skills": ["skill1"],
  "missing_skills": ["missing1"],
  "experience_level": "Entry / Mid / Senior",
  "strengths": ["point1", "point2"],
  "weaknesses": ["point1", "point2"],
  "suggestions_for_improvement": ["suggestion1", "suggestion2"],
  "recommended_job_roles": ["role1", "role2"]
}}
"""
    response = model.generate_content(
        prompt,
        generation_config={"response_mime_type": "application/json"}
    )
    return json.loads(response.text)


def main():
    if len(sys.argv) < 2:
        print("Usage: python cli_analyze.py <path_to_resume.pdf> [optional_job_description_file.txt]")
        print("Example: python cli_analyze.py resume.pdf")
        return

    pdf_path = sys.argv[1]
    if not os.path.exists(pdf_path):
        print(f"Error: File '{pdf_path}' not found.")
        return

    print(f"📄 Extracting text from '{pdf_path}'...")
    resume_text = extract_text_from_pdf(pdf_path)
    
    if not resume_text:
        print("Error: Could not extract text from the PDF. (The PDF may be scanned/an image).")
        return

    print(f"✅ Extracted {len(resume_text)} characters.")
    
    jd_text = None
    if len(sys.argv) >= 3 and os.path.exists(sys.argv[2]):
        with open(sys.argv[2], "r", encoding="utf-8", errors="ignore") as f:
            jd_text = f.read()
        print(f"📋 Loaded Job Description from '{sys.argv[2]}'.")

    print("\n🤖 Analyzing with AI ATS Engine...\n")
    analysis = analyze_resume_text(resume_text, jd_text)
    
    print("="*60)
    print(f"  ATS SCORE: {analysis.get('ats_score')}/100")
    print(f"  Candidate: {analysis.get('candidate_name')} | Level: {analysis.get('experience_level')}")
    print("="*60)
    print(f"\n📝 SUMMARY:\n{analysis.get('overall_summary')}\n")
    print(f"🎯 RECOMMENDED ROLES: {', '.join(analysis.get('recommended_job_roles', []))}\n")
    print(f"✅ EXTRACTED/MATCHED SKILLS:\n  - " + "\n  - ".join(analysis.get('matched_skills', []) or analysis.get('skills', [])))
    print(f"\n⚠️ MISSING SKILLS / KEYWORDS:\n  - " + "\n  - ".join(analysis.get('missing_skills', [])))
    print(f"\n💪 STRENGTHS:\n  - " + "\n  - ".join(analysis.get('strengths', [])))
    print(f"\n⚡ AREAS TO IMPROVE:\n  - " + "\n  - ".join(analysis.get('suggestions_for_improvement', [])))
    print("\n" + "="*60)


if __name__ == "__main__":
    main()
